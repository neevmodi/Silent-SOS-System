package com.example.silentsos

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.telephony.SmsManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import kotlin.math.sqrt
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent


class MainActivity : AppCompatActivity(), SensorEventListener {
    private lateinit var holdButton: Button
    private val holdHandler = Handler(Looper.getMainLooper())
    private var isHolding = false

    private lateinit var phoneInput: EditText
    private lateinit var messageInput: EditText
    private lateinit var saveButton: Button
    private lateinit var statusText: TextView

    private lateinit var sharedPreferences: SharedPreferences

    // Shake detection
    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private val shakeThreshold = 18.0f
    private var shakeCount = 0
    private var lastShakeTime: Long = 0

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        phoneInput = findViewById(R.id.phoneInput)
        messageInput = findViewById(R.id.messageInput)
        saveButton = findViewById(R.id.saveButton)
        statusText = findViewById(R.id.statusText)
        holdButton = findViewById(R.id.holdButton)

        holdButton.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    isHolding = true
                    statusText.text = "Holding... keep pressing"
                    holdHandler.postDelayed({
                        if (isHolding) {
                            sendSOS()
                        }
                    }, 3000) // 3 seconds
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    isHolding = false
                    statusText.text = "Hold cancelled"
                }
            }
            true
        }


        sharedPreferences = getSharedPreferences("SOS_PREFS", Context.MODE_PRIVATE)
        loadSavedData()

        saveButton.setOnClickListener {
            saveData()
        }

        // Sensor setup
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL)
    }

    private fun saveData() {
        val phones = phoneInput.text.toString().trim()
        val message = messageInput.text.toString().trim()

        if (phones.isEmpty() || message.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        val editor = sharedPreferences.edit()
        editor.putString("phones", phones)
        editor.putString("message", message)
        editor.apply()

        Toast.makeText(this, "Emergency details saved", Toast.LENGTH_SHORT).show()
    }

    private fun loadSavedData() {
        val phones = sharedPreferences.getString("phones", "")
        val message = sharedPreferences.getString("message", "")

        phoneInput.setText(phones)
        messageInput.setText(message)
    }

    // SHAKE DETECTION
    override fun onSensorChanged(event: SensorEvent) {
        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]

        val acceleration = sqrt((x * x + y * y + z * z).toDouble()).toFloat()

        if (acceleration > shakeThreshold) {
            val currentTime = System.currentTimeMillis()

            if (currentTime - lastShakeTime > 800) {
                shakeCount++
                lastShakeTime = currentTime
                statusText.text = "Shake Count: $shakeCount"

                if (shakeCount == 3) {
                    sendSOS()
                    shakeCount = 0
                }
            }
        }
    }

    private fun sendSOS() {
        val phones = sharedPreferences.getString("phones", "")
        val message = sharedPreferences.getString("message", "")

        if (phones.isNullOrEmpty() || message.isNullOrEmpty()) {
            Toast.makeText(this, "Please save emergency details first", Toast.LENGTH_SHORT).show()
            return
        }

        val locationLink = getLocation()
        val fullMessage = "$message\nMy location: $locationLink"

        val phoneList = phones.split(",")

        val smsManager = SmsManager.getDefault()

        for (number in phoneList) {
            smsManager.sendTextMessage(number.trim(), null, fullMessage, null, null)
        }

        vibratePhone()
        Toast.makeText(this, "🚨 SOS Sent!", Toast.LENGTH_LONG).show()
        statusText.text = "SOS Sent!"
    }

    private fun getLocation(): String {
        val locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.SEND_SMS),
                1
            )
            return "Location permission not granted"
        }

        val location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)

        return if (location != null) {
            "https://maps.google.com/?q=${location.latitude},${location.longitude}"
        } else {
            "Location not available"
        }
    }

    private fun vibratePhone() {
        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(
                VibrationEffect.createWaveform(longArrayOf(0, 1000, 500, 1000, 500, 1000), -1)
            )
        } else {
            vibrator.vibrate(3000)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
